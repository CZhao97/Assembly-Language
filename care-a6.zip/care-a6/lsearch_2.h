
int lsearch_2(int *A, int n, int target);

