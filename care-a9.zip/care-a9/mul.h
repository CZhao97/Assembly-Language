
#ifndef _MUL_H_
#define _MUL_H_

int **mul(int **A, int rA, int cA, int **B, int rB, int cB);

#endif // _MUL_H_
