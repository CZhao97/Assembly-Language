
int min(int, int);

int min(int a, int b) {
    if (a < b) return a;
    return b;
}

